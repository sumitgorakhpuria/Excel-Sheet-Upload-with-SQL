using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using OfficeOpenXml;

namespace Sumit_Excel
{
    public partial class UploadFile : System.Web.UI.Page
    {
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (!FileUpload1.HasFile)
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Please select a file first ";
                return;
            }

            string folderPath = Server.MapPath("~/Uploads/");
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);

            string fileName = Path.GetFileName(FileUpload1.FileName);
            string filePath = Path.Combine(folderPath, fileName);

            try
            {
                FileUpload1.SaveAs(filePath);

                ExcelPackage.License.SetNonCommercialPersonal("Sumit Chaudhary");

                DataTable dt = new DataTable();
                using (var package = new ExcelPackage(new FileInfo(filePath)))
                {
                    var ws = package.Workbook.Worksheets[0];
                    bool hasHeader = true;
                    int colCount = ws.Dimension.Columns;
                    int rowCount = ws.Dimension.Rows;

                    for (int col = 1; col <= colCount; col++)
                    {
                        string colName = hasHeader ? ws.Cells[1, col].Text.Trim() : $"Column{col}";
                        dt.Columns.Add(colName);
                    }

                    int startRow = hasHeader ? 2 : 1;
                    for (int row = startRow; row <= rowCount; row++)
                    {
                        DataRow dr = dt.NewRow();
                        for (int col = 1; col <= colCount; col++)
                        {
                            dr[col - 1] = ws.Cells[row, col].Text;
                        }
                        dt.Rows.Add(dr);
                    }
                }

                string connStr = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();

                    foreach (DataRow row in dt.Rows)
                    {
                        string query = "INSERT INTO Emp_Eng (Name, age, email, contact_number) VALUES (@Name, @age, @email, @contact_number)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", row["Name"]);
                            cmd.Parameters.AddWithValue("@age", Convert.ToInt32(row["age"]));
                            cmd.Parameters.AddWithValue("@email", row["email"]);
                            cmd.Parameters.AddWithValue("@contact_number", row["contact_number"]);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                GridView1.DataSource = dt;
                GridView1.DataBind();

                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Excel uploaded and data saved to database!";
            }
            catch (Exception ex)
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Error: " + ex.Message;
            }
        }
    }
}
